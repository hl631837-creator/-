import React, { useState, useEffect, useRef } from 'react';
import { 
  Trophy, 
  Award, 
  User, 
  Lock, 
  Volume2, 
  VolumeX, 
  Timer, 
  CheckCircle2, 
  XCircle, 
  Play, 
  Sparkles, 
  RefreshCw, 
  ChevronRight, 
  AlertCircle,
  HelpCircle,
  Trash2,
  ShieldCheck
} from 'lucide-react';

interface LeaderboardEntry {
  id: string;
  name: string;
  level: string;
  solvedCount: number;
  totalEquations: number;
  date: string;
  qualified: boolean;
}

export default function App() {
  // Screen state
  const [screen, setScreen] = useState<'welcome' | 'level_select' | 'game' | 'result'>('welcome');
  const [welcomeMode, setWelcomeMode] = useState<'role_select' | 'student_form' | 'teacher_verify' | 'teacher_dashboard'>('role_select');
  const [name, setName] = useState('');
  const [nameError, setNameError] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [passcodeError, setPasscodeError] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  
  // Audio state
  const [mute, setMute] = useState(false);
  
  // Level status popups/messages
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  
  // Game states
  const [currentEquationIndex, setCurrentEquationIndex] = useState(0);
  const [equations, setEquations] = useState<{ num1: number; num2: number; answer: number }[]>([]);
  const [userAnswer, setUserAnswer] = useState('');
  const [timeLeft, setTimeLeft] = useState(5.0); // 5 seconds
  const [score, setScore] = useState(0);
  const [isLevelFailed, setIsLevelFailed] = useState(false);
  const [isLevelPassed, setIsLevelPassed] = useState(false);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | 'timeout' | null>(null);
  const [shakeInput, setShakeInput] = useState(false);
  
  // Leaderboard loaded from localStorage
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  // Timer intervals & references
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const lastTickRef = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize Leaderboard with mock prestigious Arabian math masters
  useEffect(() => {
    const saved = localStorage.getItem('mental_arithmetic_leaderboard');
    if (saved) {
      setLeaderboard(JSON.parse(saved));
    } else {
      const initial: LeaderboardEntry[] = [
        { id: '1', name: 'أنس الحربي', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-07-02', qualified: true },
        { id: '2', name: 'جود اليافعي', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-07-01', qualified: true },
        { id: '3', name: 'عبدالرحمن العتيبي', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-07-02', qualified: true },
        { id: '4', name: 'سارة المهيري', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-06-30', qualified: true },
      ];
      localStorage.setItem('mental_arithmetic_leaderboard', JSON.stringify(initial));
      setLeaderboard(initial);
    }
  }, []);

  // Audio Synthesizer (Zero-dependency Web Audio API)
  const triggerSound = (type: 'success' | 'fail' | 'tick' | 'victory' | 'click') => {
    if (mute) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      } else if (type === 'fail') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, ctx.currentTime); // A3
        osc.frequency.linearRampToValueAtTime(110, ctx.currentTime + 0.3); // A2
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else if (type === 'tick') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
      } else if (type === 'victory') {
        const now = ctx.currentTime;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.2); // G5
        osc.frequency.setValueAtTime(1046.50, now + 0.35); // C6
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.65);
        osc.start();
        osc.stop(now + 0.65);
      } else if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
        osc.start();
        osc.stop(ctx.currentTime + 0.08);
      }
    } catch (e) {
      console.warn("AudioContext block or failed to initialize", e);
    }
  };

  // Helper to generate a random odd number
  const getOddNumber = (min: number, max: number): number => {
    let num = Math.floor(Math.random() * (max - min + 1)) + min;
    if (num % 2 === 0) {
      num += 1;
      if (num > max) num -= 2;
    }
    return num;
  };

  // Setup Level 1 Equations (Exactly 3 equations, adding two single-digit odd numbers)
  const generateLevel1Equations = () => {
    const list = [];
    const oddDigits = [1, 3, 5, 7, 9];
    for (let i = 0; i < 3; i++) {
      // Create distinct combinations of single-digit odd numbers
      const num1 = oddDigits[Math.floor(Math.random() * oddDigits.length)];
      let num2 = oddDigits[Math.floor(Math.random() * oddDigits.length)];
      while (num2 === num1) {
        num2 = oddDigits[Math.floor(Math.random() * oddDigits.length)];
      }
      list.push({
        num1,
        num2,
        answer: num1 + num2
      });
    }
    return list;
  };

  // Handle Enter App
  const handleStartApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setNameError(true);
      triggerSound('fail');
      setTimeout(() => setNameError(false), 500);
      return;
    }
    triggerSound('click');
    setScreen('level_select');
  };

  // Verify Teacher Passcode
  const handleVerifyTeacherPasscode = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode.trim() === '09818767661') {
      triggerSound('victory');
      setWelcomeMode('teacher_dashboard');
      setName('المعلم المشرف');
      setPasscodeError(false);
    } else {
      triggerSound('fail');
      setPasscodeError(true);
      // Exit the list of teachers if incorrect passcode is supplied
      setTimeout(() => {
        setWelcomeMode('role_select');
        setPasscode('');
        setPasscodeError(false);
      }, 1500);
    }
  };

  // Clear single entry for teacher
  const deleteLeaderboardEntry = (id: string) => {
    triggerSound('fail');
    const updated = leaderboard.filter(item => item.id !== id);
    setLeaderboard(updated);
    localStorage.setItem('mental_arithmetic_leaderboard', JSON.stringify(updated));
  };

  // Reset entire leaderboard for teacher
  const resetLeaderboard = () => {
    triggerSound('click');
    const initial: LeaderboardEntry[] = [
      { id: '1', name: 'أنس الحربي', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-07-02', qualified: true },
      { id: '2', name: 'جود اليافعي', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-07-01', qualified: true },
      { id: '3', name: 'عبدالرحمن العتيبي', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-07-02', qualified: true },
      { id: '4', name: 'سارة المهيري', level: 'المستوى الأول', solvedCount: 3, totalEquations: 3, date: '2026-06-30', qualified: true },
    ];
    setLeaderboard(initial);
    localStorage.setItem('mental_arithmetic_leaderboard', JSON.stringify(initial));
  };

  // Launch Test for Level 1
  const startLevel1Test = () => {
    triggerSound('click');
    setSelectedLevel(1);
    const newEqs = generateLevel1Equations();
    setEquations(newEqs);
    setCurrentEquationIndex(0);
    setScore(0);
    setUserAnswer('');
    setIsLevelFailed(false);
    setIsLevelPassed(false);
    setFeedback(null);
    setTimeLeft(5.0);
    setScreen('game');
  };

  // Manage Countdown timer for current question
  useEffect(() => {
    if (screen !== 'game' || isLevelFailed || isLevelPassed || feedback) return;

    // Focus input on each new question
    if (inputRef.current) {
      inputRef.current.focus();
    }

    const intervalMs = 100;
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0.1) {
          clearInterval(timerRef.current!);
          handleQuestionTimeout();
          return 0;
        }
        // Sub-second tick audio indicator in the final seconds
        if (Math.ceil(prev) !== Math.ceil(prev - 0.1) && prev < 3.0) {
          triggerSound('tick');
        }
        return Math.round((prev - 0.1) * 10) / 10;
      });
    }, intervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [screen, currentEquationIndex, isLevelFailed, isLevelPassed, feedback]);

  // If time runs out
  const handleQuestionTimeout = () => {
    setFeedback('timeout');
    triggerSound('fail');
    setIsLevelFailed(true);
    
    // Automatically transition to results after showing feedback
    setTimeout(() => {
      recordResult(score, false);
      setScreen('result');
    }, 1500);
  };

  // Submit current answer
  const handleSubmitAnswer = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (feedback || isLevelFailed || isLevelPassed) return;

    const currentEq = equations[currentEquationIndex];
    const parsedUserAnswer = parseInt(userAnswer.trim(), 10);

    if (parsedUserAnswer === currentEq.answer) {
      // Correct answer!
      setFeedback('correct');
      triggerSound('success');
      const newScore = score + 1;
      setScore(newScore);

      if (timerRef.current) clearInterval(timerRef.current);

      setTimeout(() => {
        if (currentEquationIndex + 1 < 3) {
          // Move to next equation
          setCurrentEquationIndex((prev) => prev + 1);
          setUserAnswer('');
          setFeedback(null);
          setTimeLeft(5.0);
        } else {
          // Success! Passed all 3 equations
          setIsLevelPassed(true);
          triggerSound('victory');
          recordResult(newScore, true);
          setScreen('result');
        }
      }, 1000);
    } else {
      // Incorrect answer! Immediate failure as per strict rules
      setFeedback('wrong');
      setShakeInput(true);
      triggerSound('fail');
      if (timerRef.current) clearInterval(timerRef.current);
      setIsLevelFailed(true);

      setTimeout(() => {
        setShakeInput(false);
        recordResult(score, false);
        setScreen('result');
      }, 1500);
    }
  };

  // Record contestant results inside the Leaderboard list
  const recordResult = (finalScore: number, passed: boolean) => {
    const normalizedNewName = name.trim().toLowerCase();
    const existingIndex = leaderboard.findIndex(
      entry => entry.name.trim().toLowerCase() === normalizedNewName
    );

    let updatedLeaderboard = [...leaderboard];

    if (existingIndex !== -1) {
      const existingEntry = leaderboard[existingIndex];
      // Compare strength:
      // A result is stronger if:
      // 1. It is qualified (passed === true) while the old one wasn't.
      // 2. Both are qualified or both not, but finalScore > existingEntry.solvedCount.
      const isNewStronger = 
        (passed && !existingEntry.qualified) ||
        (passed === existingEntry.qualified && finalScore > existingEntry.solvedCount);

      if (isNewStronger) {
        // Replace with the new stronger attempt
        updatedLeaderboard[existingIndex] = {
          ...existingEntry,
          id: Date.now().toString(),
          solvedCount: finalScore,
          qualified: passed,
          date: new Date().toISOString().split('T')[0]
        };
      }
      // Otherwise, keep the old stronger record and do not update
    } else {
      // If no entry exists for this name, insert a new entry
      const newEntry: LeaderboardEntry = {
        id: Date.now().toString(),
        name: name.trim(),
        level: 'المستوى الأول',
        solvedCount: finalScore,
        totalEquations: 3,
        date: new Date().toISOString().split('T')[0],
        qualified: passed
      };
      updatedLeaderboard = [newEntry, ...updatedLeaderboard];
    }

    // Sort leaderboard to keep top qualified performers at the top, then by score
    updatedLeaderboard.sort((a, b) => {
      if (a.qualified && !b.qualified) return -1;
      if (!a.qualified && b.qualified) return 1;
      if (a.solvedCount !== b.solvedCount) {
        return b.solvedCount - a.solvedCount;
      }
      return b.id.localeCompare(a.id);
    });

    // Keep only top 15 results to look pristine
    const trimmed = updatedLeaderboard.slice(0, 15);
    setLeaderboard(trimmed);
    localStorage.setItem('mental_arithmetic_leaderboard', JSON.stringify(trimmed));
  };

  // Custom key buttons for beautiful mobile interactivity
  const handleKeypadPress = (val: string) => {
    triggerSound('click');
    if (val === 'back') {
      setUserAnswer(prev => prev.slice(0, -1));
    } else if (val === 'clear') {
      setUserAnswer('');
    } else {
      setUserAnswer(prev => prev + val);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between overflow-x-hidden selection:bg-indigo-500 selection:text-white relative">
      
      {/* Absolute Decorative Floating Glows */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-indigo-900/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-emerald-900/10 rounded-full blur-3xl pointer-events-none" />

      {/* Persistent Beautiful Header Bar */}
      <header id="app-header" className="border-b border-slate-800/60 bg-slate-900/40 backdrop-blur-md sticky top-0 z-50 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-500/10 p-2 rounded-xl border border-indigo-500/30">
              <Trophy className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-slate-100 tracking-wide font-Cairo">
                المعهد البريطاني <span className="text-indigo-400">للحساب الذهني</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-Cairo">التقييم الرياضي المعتمد والمتقدم</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setMute(!mute)}
              className="p-2 rounded-lg bg-slate-800/40 border border-slate-700/50 text-slate-400 hover:text-slate-200 transition-colors"
              title={mute ? "تشغيل الصوت" : "كتم الصوت"}
              id="sound-toggle-btn"
            >
              {mute ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-indigo-400" />}
            </button>

            {screen !== 'welcome' && (
              <div className="px-3 py-1.5 rounded-lg bg-slate-800/40 border border-slate-700/50 flex items-center gap-1.5 text-xs">
                <User className="w-4 h-4 text-indigo-400" />
                <span className="font-semibold text-indigo-200 font-Cairo">{name}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow flex items-center justify-center p-4 max-w-6xl w-full mx-auto z-10">
        
        {/* WELCOME SCREEN */}
        {screen === 'welcome' && (
          <div id="welcome-card" className="w-full max-w-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-6 md:p-8 rounded-3xl neon-glow text-center flex flex-col items-center">
            
            {/* Logo */}
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-8 h-8 text-white animate-pulse" />
            </div>

            <h2 className="text-2xl md:text-3xl font-extrabold font-Cairo mb-2 text-slate-100 leading-snug">
              المعهد البريطاني للحساب الذهني
            </h2>
            <p className="text-slate-400 text-xs md:text-sm mb-8 font-Cairo leading-relaxed max-w-md">
              التقييم السنوي المعتمد لقياس القدرات الحسابية السريعة والذكاء الذهني المتطور
            </p>

            {/* 1. ROLE SELECTION */}
            {welcomeMode === 'role_select' && (
              <div className="w-full space-y-6 animate-fade-in">
                <div className="text-center mb-2">
                  <span className="inline-block bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full px-4 py-1 text-xs font-Cairo font-semibold">
                    يرجى تحديد صفة الدخول للمنصة التقييمية
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                  {/* Student Option Card */}
                  <div
                    onClick={() => {
                      triggerSound('click');
                      setWelcomeMode('student_form');
                    }}
                    id="role-student-card"
                    className="bg-slate-950/60 border border-slate-800 hover:border-indigo-500/60 p-6 rounded-2xl cursor-pointer hover:bg-slate-900/50 transition-all text-right group flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl group-hover:scale-110 transition-transform">
                        <User className="w-6 h-6" />
                      </div>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full font-Cairo font-bold">متاح للجميع</span>
                    </div>
                    <div>
                      <h3 className="text-lg font-bold font-Cairo text-slate-200 group-hover:text-indigo-400 transition-colors mb-1">
                        دخول بصفة طالب (متسابق)
                      </h3>
                      <p className="text-xs text-slate-400 font-Cairo leading-relaxed">
                        ابدأ التقييم الرياضي الموقّت لحساب الأرقام الفردية واكسب مكانك بقائمة المتأهلين.
                      </p>
                    </div>
                  </div>

                  {/* Teacher Option Card */}
                  <div
                    onClick={() => {
                      triggerSound('click');
                      setWelcomeMode('teacher_verify');
                    }}
                    id="role-teacher-card"
                    className="bg-slate-950/60 border border-slate-800 hover:border-indigo-500/60 p-6 rounded-2xl cursor-pointer hover:bg-slate-900/50 transition-all text-right group flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl group-hover:scale-110 transition-transform">
                        <Lock className="w-6 h-6" />
                      </div>
                      <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2.5 py-1 rounded-full font-Cairo font-bold">بوابة خاصة</span>
                    </div>
                    <div>
                      <h3 className="text-lg font-bold font-Cairo text-slate-200 group-hover:text-indigo-400 transition-colors mb-1">
                        دخول بصفة معلم (مشرف)
                      </h3>
                      <p className="text-xs text-slate-400 font-Cairo leading-relaxed">
                        يتطلب الرمز السري للمعهد. يسمح بالتحكم بلوحة الشرف، تصفير السجلات وإدارة المتأهلين.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-800/20 p-3 rounded-xl border border-slate-800/80 text-center text-[11px] text-slate-500 font-Cairo">
                  بوابة مشفرة ومصممة وفق معايير التقييم البريطاني المتقدم للحساب الذهني
                </div>
              </div>
            )}

            {/* 2. STUDENT REGISTRATION FORM */}
            {welcomeMode === 'student_form' && (
              <div className="w-full max-w-md space-y-6 animate-fade-in text-right">
                <div className="flex items-center justify-between mb-4">
                  <button
                    onClick={() => {
                      triggerSound('click');
                      setWelcomeMode('role_select');
                    }}
                    className="flex items-center gap-1 text-slate-400 hover:text-slate-200 text-xs font-Cairo transition-all cursor-pointer"
                    id="back-to-roles-student"
                  >
                    <ChevronRight className="w-4 h-4 rotate-180" />
                    الرجوع للرئيسية
                  </button>
                  <span className="text-xs bg-indigo-500/10 text-indigo-400 px-3 py-1 rounded-full font-Cairo font-bold">بوابة الطلاب</span>
                </div>

                <form onSubmit={handleStartApp} className="w-full space-y-4">
                  <div>
                    <label htmlFor="contestant-name" className="block text-slate-300 text-xs font-bold mb-2 font-Cairo pr-1">
                      اسم المتسابق الكريم (أي اسم تريده):
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        id="contestant-name"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (nameError) setNameError(false);
                        }}
                        placeholder="أدخل اسمك الكريم للانطلاق..."
                        className={`w-full bg-slate-950/80 border text-slate-100 text-center rounded-2xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 font-Cairo text-base transition-all ${
                          nameError ? 'border-rose-500 animate-shake bg-rose-500/5' : 'border-slate-800 focus:border-indigo-500'
                        }`}
                        autoFocus
                      />
                      {nameError && (
                        <p className="text-rose-400 text-xs mt-1.5 font-Cairo text-right flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> يرجى إدخال اسم المتسابق أولاً للاستمرار
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    type="submit"
                    id="enter-challenge-btn"
                    className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-extrabold font-Cairo py-4 px-6 rounded-2xl shadow-lg hover:shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 text-base cursor-pointer"
                  >
                    دخول التحدي الآن
                    <Play className="w-4 h-4 fill-current" />
                  </button>
                </form>

                <div className="flex items-start gap-2 bg-indigo-500/5 p-3 rounded-xl border border-indigo-500/10 w-full text-[11px] text-slate-400 font-Cairo">
                  <AlertCircle className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
                  <span>بعد إدخال اسمك ستظهر قائمة المستويات الحسابية لتختار المستوى الأول المتاح (الأرقام الفردية).</span>
                </div>
              </div>
            )}

            {/* 3. TEACHER PASSCODE VERIFICATION */}
            {welcomeMode === 'teacher_verify' && (
              <div className="w-full max-w-md space-y-6 animate-fade-in text-right">
                <div className="flex items-center justify-between mb-4">
                  <button
                    onClick={() => {
                      triggerSound('click');
                      setWelcomeMode('role_select');
                    }}
                    className="flex items-center gap-1 text-slate-400 hover:text-slate-200 text-xs font-Cairo transition-all cursor-pointer"
                    id="back-to-roles-teacher"
                  >
                    <ChevronRight className="w-4 h-4 rotate-180" />
                    الرجوع للرئيسية
                  </button>
                  <span className="text-xs bg-rose-500/10 text-rose-400 px-3 py-1 rounded-full font-Cairo font-bold">بوابة المعلمين</span>
                </div>

                <form onSubmit={handleVerifyTeacherPasscode} className="w-full space-y-4">
                  <div>
                    <label htmlFor="teacher-passcode" className="block text-slate-300 text-xs font-bold mb-2 font-Cairo pr-1">
                      الرمز السري الخاص بالمعلم المعتمد:
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        id="teacher-passcode"
                        value={passcode}
                        onChange={(e) => {
                          setPasscode(e.target.value);
                          if (passcodeError) setPasscodeError(false);
                        }}
                        placeholder="أدخل الرمز السري (11 رقم)..."
                        className={`w-full bg-slate-950/80 border text-slate-100 text-center rounded-2xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-rose-500/50 font-mono tracking-widest text-base transition-all ${
                          passcodeError ? 'border-rose-500 animate-shake bg-rose-500/5 text-rose-300' : 'border-slate-800 focus:border-rose-500'
                        }`}
                        autoFocus
                      />
                      {passcodeError && (
                        <p className="text-rose-400 text-xs mt-1.5 font-Cairo text-right flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> الرمز السري غير صحيح! سيتم إخراجك فوراً من بوابة المعلمين...
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    type="submit"
                    id="verify-passcode-btn"
                    className="w-full bg-gradient-to-r from-rose-500 to-amber-600 hover:from-rose-600 hover:to-amber-700 text-white font-extrabold font-Cairo py-4 px-6 rounded-2xl shadow-lg hover:shadow-rose-500/25 transition-all flex items-center justify-center gap-2 text-base cursor-pointer"
                  >
                    التحقق وتأكيد الهوية
                    <ShieldCheck className="w-4 h-4" />
                  </button>
                </form>

                <div className="bg-rose-500/5 p-3 rounded-xl border border-rose-500/10 w-full text-[11px] text-slate-400 font-Cairo text-center">
                  تنبيه: إذا تم إدخل رمز خاطئ، سيتم إرجاعك تلقائياً لبوابة الاختيار لضمان الخصوصية.
                </div>
              </div>
            )}

            {/* 4. TEACHER DASHBOARD */}
            {welcomeMode === 'teacher_dashboard' && (
              <div className="w-full space-y-6 animate-fade-in text-right">
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div>
                    <h3 className="text-lg font-bold font-Cairo text-emerald-400 flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5" />
                      بوابة المعلم المشرف المعتمدة
                    </h3>
                    <p className="text-[10px] text-slate-400 font-Cairo mt-0.5">المعهد البريطاني للحساب الذهني</p>
                  </div>
                  <button
                    onClick={() => {
                      triggerSound('click');
                      setWelcomeMode('role_select');
                      setName('');
                    }}
                    className="bg-rose-500/10 text-rose-400 border border-rose-500/20 px-3 py-1.5 rounded-xl font-Cairo text-xs font-bold hover:bg-rose-500/20 transition-all cursor-pointer"
                  >
                    خروج من لوحة المعلم
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
                    <span className="text-xs text-slate-400 font-Cairo">إجمالي المتأهلين المسجلين في النظام</span>
                    <span className="text-2xl font-bold text-indigo-400 font-mono mt-2">
                      {leaderboard.filter(player => player.qualified).length} متسابقين
                    </span>
                  </div>

                  <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
                    <span className="text-xs text-slate-400 font-Cairo">أدوات التحكم العام بالمنصة</span>
                    <button
                      onClick={() => {
                        if (confirm('هل أنت متأكد من رغبتك في تصفير وإعادة تعيين لوحة الشرف بأكملها؟')) {
                          resetLeaderboard();
                        }
                      }}
                      className="mt-2 w-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 px-3 py-2 rounded-lg font-Cairo text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      إعادة تعيين لوحة الصدارة بالكامل
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-sm font-extrabold font-Cairo text-slate-200">إدارة ومراجعة سجلات الطلاب المتأهلين:</h4>
                  
                  <div className="overflow-y-auto max-h-[200px] border border-slate-800 rounded-xl bg-slate-950/60 p-2 space-y-2">
                    {leaderboard.filter(player => player.qualified).length === 0 ? (
                      <div className="text-center py-8 text-slate-500 text-xs font-Cairo">
                        لا يوجد طلاب متأهلين مسجلين حالياً.
                      </div>
                    ) : (
                      leaderboard.filter(player => player.qualified).map((player, index) => (
                        <div
                          key={player.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-slate-900/50 border border-slate-800/80 text-xs"
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-5 h-5 rounded bg-indigo-500/10 text-indigo-300 flex items-center justify-center font-bold">
                              {index + 1}
                            </span>
                            <div>
                              <div className="font-bold text-slate-200 font-Cairo">{player.name}</div>
                              <div className="text-[10px] text-slate-500 font-Cairo mt-0.5">{player.date} | {player.level}</div>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded font-Cairo font-semibold text-[10px]">
                              أجاب {player.solvedCount}/3
                            </span>
                            <button
                              onClick={() => deleteLeaderboardEntry(player.id)}
                              className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 transition-all cursor-pointer"
                              title="حذف هذا السجل"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="flex justify-center pt-2">
                  <button
                    onClick={() => {
                      triggerSound('click');
                      setScreen('level_select');
                    }}
                    className="w-full bg-gradient-to-r from-emerald-500 to-indigo-600 hover:from-emerald-600 hover:to-indigo-700 text-white font-extrabold font-Cairo py-3 px-5 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm cursor-pointer"
                  >
                    تصفح المستويات كمعلم
                    <Play className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* LEVEL SELECT SCREEN */}
        {screen === 'level_select' && (
          <div id="level-select-container" className="w-full max-w-4xl space-y-8 py-4">
            
            <div className="text-center max-w-xl mx-auto space-y-2">
              <div className="inline-flex items-center gap-2 bg-indigo-500/10 text-indigo-400 px-3 py-1 rounded-full text-xs font-bold font-Cairo border border-indigo-500/20">
                <Award className="w-4 h-4" /> مرحلة الاختيار والتصنيف
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold font-Cairo text-slate-100">
                اختر المستوى الرياضي المناسب
              </h2>
              <p className="text-sm text-slate-400 font-Cairo">
                المستوى الأول متاح حالياً لاختبار قدراتك، وباقي المستويات الاحترافية ستضاف في التحديثات القادمة.
              </p>
            </div>

            {/* Display active notification message if set */}
            {alertMessage && (
              <div className="bg-slate-900 border-l-4 border-amber-500 text-amber-300 p-4 rounded-xl flex items-center justify-between max-w-xl mx-auto font-Cairo text-xs animate-pulse">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{alertMessage}</span>
                </div>
                <button 
                  onClick={() => setAlertMessage(null)} 
                  className="text-slate-400 hover:text-white font-bold p-1"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Level Options Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Level 1 - Active */}
              <div 
                onClick={startLevel1Test}
                id="level-1-card"
                className="bg-gradient-to-br from-slate-900/90 to-indigo-950/20 border-2 border-indigo-500/40 p-6 rounded-3xl cursor-pointer hover:border-indigo-400 hover:shadow-lg hover:shadow-indigo-500/10 transition-all flex flex-col justify-between group relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-xl group-hover:bg-indigo-500/10 transition-all" />
                
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-indigo-500 text-white font-extrabold px-3 py-1 rounded-lg text-xs font-Cairo shadow-sm">
                      متاح حالياً
                    </span>
                    <span className="text-[10px] text-indigo-300 bg-indigo-500/10 px-2.5 py-1 rounded-full font-Cairo font-semibold">
                      مستوى تأهيلي
                    </span>
                  </div>

                  <h3 className="text-xl font-extrabold font-Cairo text-slate-100 mb-2 group-hover:text-indigo-300 transition-colors">
                    المستوى الأول: وميض الآحاد الفردية
                  </h3>
                  <p className="text-xs text-slate-400 font-Cairo mb-4 leading-relaxed">
                    يتكون هذا المستوى التقييمي من <span className="text-indigo-400 font-semibold">3 معادلات حسابية</span>. 
                    كل معادلة عبارة عن <span className="text-indigo-400 font-semibold">جمع رقمين فرديين مميزين (من الأرقام: 1، 3، 5، 7، 9)</span>. 
                    لديك <span className="text-rose-400 font-semibold">5 ثوانٍ فقط</span> لحل كل معادلة قبل انقضاء الوقت!
                  </p>
                </div>

                <div className="border-t border-slate-800/80 pt-4 flex items-center justify-between">
                  <div className="flex gap-4 text-xs text-slate-400 font-Cairo">
                    <div>
                      <span className="text-slate-500">الأسئلة: </span>
                      <span className="font-bold text-slate-300">3 معادلات</span>
                    </div>
                    <div>
                      <span className="text-slate-500">المؤقت: </span>
                      <span className="font-bold text-rose-400">5 ثوانٍ/سؤال</span>
                    </div>
                  </div>
                  <span className="text-indigo-400 font-extrabold text-xs flex items-center gap-1 group-hover:translate-x-[-4px] transition-transform font-Cairo">
                    ابدأ الاختبار
                    <ChevronRight className="w-4 h-4 rotate-180" />
                  </span>
                </div>
              </div>

              {/* Level 2 - Disabled */}
              <div 
                onClick={() => {
                  triggerSound('click');
                  setAlertMessage("قريباً ستضاف باقي المستويات المتقدمة من المعهد البريطاني للحساب الذهني!");
                }}
                id="level-2-card"
                className="bg-slate-900/30 border border-slate-800 p-6 rounded-3xl cursor-pointer hover:bg-slate-900/50 hover:border-slate-700/80 transition-all flex flex-col justify-between group relative opacity-80"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-slate-800 text-slate-400 font-bold px-3 py-1 rounded-lg text-xs font-Cairo border border-slate-700">
                      قريباً جداً
                    </span>
                    <Lock className="w-4 h-4 text-slate-500" />
                  </div>

                  <h3 className="text-xl font-extrabold font-Cairo text-slate-400 mb-2">
                    المستوى الثاني: البرق الثنائي والكسور
                  </h3>
                  <p className="text-xs text-slate-500 font-Cairo mb-4 leading-relaxed">
                    مستوى متطور للرياضيين في الحساب الذهني الفائق. يتضمن عمليات طرح وطرح مضاعف للأرقام الفردية والزوجية بسرعة استجابة 4 ثوانٍ فقط.
                  </p>
                </div>

                <div className="border-t border-slate-800/40 pt-4 flex items-center justify-between">
                  <div className="flex gap-4 text-xs text-slate-500 font-Cairo">
                    <div>
                      <span className="text-slate-600">الأسئلة: </span>
                      <span className="font-bold text-slate-500">5 معادلات</span>
                    </div>
                    <div>
                      <span className="text-slate-600">المؤقت: </span>
                      <span className="font-bold text-slate-500">4 ثوانٍ/سؤال</span>
                    </div>
                  </div>
                  <span className="text-slate-500 font-bold text-xs font-Cairo">
                    مغلق حالياً
                  </span>
                </div>
              </div>

              {/* Level 3 - Disabled */}
              <div 
                onClick={() => {
                  triggerSound('click');
                  setAlertMessage("قريباً ستضاف باقي المستويات المتقدمة من المعهد البريطاني للحساب الذهني!");
                }}
                id="level-3-card"
                className="bg-slate-900/30 border border-slate-800 p-6 rounded-3xl cursor-pointer hover:bg-slate-900/50 hover:border-slate-700/80 transition-all flex flex-col justify-between group relative opacity-80"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-slate-800 text-slate-400 font-bold px-3 py-1 rounded-lg text-xs font-Cairo border border-slate-700">
                      قريباً جداً
                    </span>
                    <Lock className="w-4 h-4 text-slate-500" />
                  </div>

                  <h3 className="text-xl font-extrabold font-Cairo text-slate-400 mb-2">
                    المستوى الثالث: عاصفة الضرب الذهني المتعدد
                  </h3>
                  <p className="text-xs text-slate-500 font-Cairo mb-4 leading-relaxed">
                    ضرب سريع للأعداد الفردية المكونة من خانتين وعشرية متقاطعة خلال 3 ثوانٍ فقط لكل معادلة. مصمم للأبطال الأولمبيين.
                  </p>
                </div>

                <div className="border-t border-slate-800/40 pt-4 flex items-center justify-between">
                  <div className="flex gap-4 text-xs text-slate-500 font-Cairo">
                    <div>
                      <span className="text-slate-600">الأسئلة: </span>
                      <span className="font-bold text-slate-500">10 معادلات</span>
                    </div>
                    <div>
                      <span className="text-slate-600">المؤقت: </span>
                      <span className="font-bold text-slate-500">3 ثوانٍ/سؤال</span>
                    </div>
                  </div>
                  <span className="text-slate-500 font-bold text-xs font-Cairo">
                    مغلق حالياً
                  </span>
                </div>
              </div>

              {/* Level 4 - Disabled */}
              <div 
                onClick={() => {
                  triggerSound('click');
                  setAlertMessage("قريباً ستضاف باقي المستويات المتقدمة من المعهد البريطاني للحساب الذهني!");
                }}
                id="level-4-card"
                className="bg-slate-900/30 border border-slate-800 p-6 rounded-3xl cursor-pointer hover:bg-slate-900/50 hover:border-slate-700/80 transition-all flex flex-col justify-between group relative opacity-80"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-slate-800 text-slate-400 font-bold px-3 py-1 rounded-lg text-xs font-Cairo border border-slate-700">
                      قريباً جداً
                    </span>
                    <Lock className="w-4 h-4 text-slate-500" />
                  </div>

                  <h3 className="text-xl font-extrabold font-Cairo text-slate-400 mb-2">
                    المستوى الرابع: التحدي الإمبراطوري المتكامل
                  </h3>
                  <p className="text-xs text-slate-500 font-Cairo mb-4 leading-relaxed">
                    تحدي الحساب الشامل والجمع والطرح والضرب العشوائي في نفس الاختبار. صمم لاختبار أقصى درجات المرونة والتحمل العقلي.
                  </p>
                </div>

                <div className="border-t border-slate-800/40 pt-4 flex items-center justify-between">
                  <div className="flex gap-4 text-xs text-slate-500 font-Cairo">
                    <div>
                      <span className="text-slate-600">الأسئلة: </span>
                      <span className="font-bold text-slate-500">15 معادلة</span>
                    </div>
                    <div>
                      <span className="text-slate-600">المؤقت: </span>
                      <span className="font-bold text-slate-500">2.5 ثانية</span>
                    </div>
                  </div>
                  <span className="text-slate-500 font-bold text-xs font-Cairo">
                    مغلق حالياً
                  </span>
                </div>
              </div>

            </div>

            {/* Back to Welcome view */}
            <div className="text-center pt-2">
              <button
                onClick={() => {
                  triggerSound('click');
                  setScreen('welcome');
                }}
                className="text-slate-400 hover:text-slate-200 text-xs font-Cairo inline-flex items-center gap-1.5 hover:underline"
              >
                تغيير اسم المتسابق والرجوع للرئيسية
              </button>
            </div>
          </div>
        )}

        {/* ACTIVE GAME TESTING SCREEN */}
        {screen === 'game' && selectedLevel === 1 && (
          <div id="active-test-card" className="w-full max-w-xl bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 p-6 md:p-8 rounded-3xl neon-glow flex flex-col items-center">
            
            {/* Header info for game */}
            <div className="w-full flex items-center justify-between mb-8 border-b border-slate-800/80 pb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                <span className="text-xs font-Cairo font-semibold text-slate-300">الاختبار جارٍ حالياً...</span>
              </div>
              <div className="text-xs font-Cairo bg-indigo-500/10 text-indigo-300 px-3 py-1.5 rounded-xl border border-indigo-500/20">
                المعادلة الحالية: <span className="font-extrabold text-indigo-400 text-sm">{currentEquationIndex + 1}</span> من <span className="font-bold">3</span>
              </div>
            </div>

            {/* Circular Timer & Equations area */}
            <div className="w-full flex flex-col items-center justify-center space-y-6">
              
              {/* Dynamic countdown visual bar */}
              <div className="w-full max-w-xs bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800 relative">
                <div 
                  style={{ width: `${(timeLeft / 5.0) * 100}%` }}
                  className={`h-full rounded-full transition-all duration-100 ${
                    timeLeft > 2.0 
                      ? 'bg-gradient-to-r from-emerald-500 to-indigo-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]' 
                      : 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.4)]'
                  }`}
                />
              </div>

              {/* Timer text indicator */}
              <div className="flex items-center gap-1.5">
                <Timer className={`w-4 h-4 ${timeLeft > 2.0 ? 'text-emerald-400' : 'text-rose-400 animate-pulse'}`} />
                <span className={`text-sm font-mono font-bold tracking-wider ${timeLeft > 2.0 ? 'text-emerald-300' : 'text-rose-400'}`}>
                  {timeLeft.toFixed(1)} ثانية متبقية
                </span>
              </div>

              {/* Strict Odd Numbers Indicator Alert */}
              <div className="text-center">
                <span className="inline-block bg-indigo-500/5 text-indigo-300 border border-indigo-500/10 rounded-full px-3 py-0.5 text-[10px] font-Cairo mb-3">
                  تحدي جمع رقمين فرديين (1، 3، 5، 7، 9)
                </span>
              </div>

              {/* Big Interactive Equation Output */}
              {equations[currentEquationIndex] && (
                <div className="py-6 px-8 bg-slate-950/80 border border-slate-800 rounded-3xl text-center w-full shadow-inner relative overflow-hidden">
                  
                  {/* Feedback overlay */}
                  {feedback === 'correct' && (
                    <div className="absolute inset-0 bg-emerald-500/10 flex items-center justify-center z-10 animate-fade-in">
                      <span className="text-emerald-400 font-Cairo font-extrabold text-base md:text-lg flex items-center gap-1">
                        <CheckCircle2 className="w-5 h-5" /> صحيح! أحسنت صنعاً
                      </span>
                    </div>
                  )}

                  {feedback === 'wrong' && (
                    <div className="absolute inset-0 bg-rose-500/10 flex items-center justify-center z-10 animate-fade-in">
                      <span className="text-rose-400 font-Cairo font-extrabold text-base md:text-lg flex items-center gap-1">
                        <XCircle className="w-5 h-5" /> خطأ! إجابة غير دقيقة
                      </span>
                    </div>
                  )}

                  {feedback === 'timeout' && (
                    <div className="absolute inset-0 bg-rose-500/10 flex items-center justify-center z-10 animate-fade-in">
                      <span className="text-rose-400 font-Cairo font-extrabold text-base md:text-lg flex items-center gap-1">
                        <AlertCircle className="w-5 h-5" /> انتهى الوقت المخصص!
                      </span>
                    </div>
                  )}

                  {/* Math text display */}
                  <div className="flex items-center justify-center gap-4 text-3xl md:text-5xl font-extrabold font-mono text-slate-100 tracking-wide select-none">
                    <span className="text-indigo-300">{equations[currentEquationIndex].num1}</span>
                    <span className="text-slate-500 font-normal text-2xl md:text-3xl">+</span>
                    <span className="text-indigo-300">{equations[currentEquationIndex].num2}</span>
                    <span className="text-slate-500 font-normal text-2xl md:text-3xl">=</span>
                    <span className="text-emerald-400 font-normal text-2xl md:text-3xl">؟</span>
                  </div>
                </div>
              )}

              {/* Input Form */}
              <form onSubmit={handleSubmitAnswer} className="w-full space-y-4 pt-2">
                <input
                  ref={inputRef}
                  type="number"
                  pattern="[0-9]*"
                  inputMode="numeric"
                  value={userAnswer}
                  onChange={(e) => {
                    if (!feedback) setUserAnswer(e.target.value);
                  }}
                  placeholder="أدخل الناتج الحسابي الصحيح هنا..."
                  className={`w-full bg-slate-950 border text-slate-100 text-center rounded-2xl px-4 py-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 font-mono text-2xl transition-all ${
                    shakeInput ? 'border-rose-500 animate-shake bg-rose-500/5' : 'border-slate-800 focus:border-indigo-500'
                  }`}
                  disabled={feedback !== null}
                  autoFocus
                />

                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      triggerSound('click');
                      // Cancel current test, reset to selection
                      if (timerRef.current) clearInterval(timerRef.current);
                      setScreen('level_select');
                    }}
                    className="bg-slate-800/50 hover:bg-slate-800 text-slate-400 font-bold font-Cairo py-3 px-4 rounded-xl transition-all text-xs"
                  >
                    انسحاب وإلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={feedback !== null || !userAnswer.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold font-Cairo py-3 px-4 rounded-xl transition-all text-xs shadow-lg shadow-indigo-600/10 cursor-pointer"
                  >
                    تأكيد الإجابة
                  </button>
                </div>
              </form>

              {/* Custom Numeric Keypad for excellent Touch interaction on mobile */}
              <div className="w-full max-w-sm pt-4 border-t border-slate-800/40 mt-2">
                <div className="grid grid-cols-3 gap-2 text-center">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleKeypadPress(num.toString())}
                      disabled={feedback !== null}
                      className="bg-slate-800/40 hover:bg-slate-800 border border-slate-800 hover:border-slate-700/80 py-3 rounded-xl text-lg font-bold font-mono text-slate-200 transition-all cursor-pointer active:scale-95 disabled:opacity-40"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('clear')}
                    disabled={feedback !== null}
                    className="bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/30 text-rose-300 py-3 rounded-xl text-xs font-bold font-Cairo transition-all cursor-pointer active:scale-95 disabled:opacity-40"
                  >
                    مسح
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('0')}
                    disabled={feedback !== null}
                    className="bg-slate-800/40 hover:bg-slate-800 border border-slate-800 hover:border-slate-700/80 py-3 rounded-xl text-lg font-bold font-mono text-slate-200 transition-all cursor-pointer active:scale-95 disabled:opacity-40"
                  >
                    0
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('back')}
                    disabled={feedback !== null}
                    className="bg-slate-800/40 hover:bg-slate-800 border border-slate-800 hover:border-slate-700/80 py-3 rounded-xl text-xs font-bold font-Cairo text-slate-400 transition-all cursor-pointer active:scale-95 disabled:opacity-40"
                  >
                    حذف
                  </button>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* RESULTS & HALL OF FAME / QUALIFIERS LEADERBOARD SCREEN */}
        {screen === 'result' && (
          <div id="results-and-leaderboard" className="w-full max-w-4xl space-y-8 py-4">
            
            {/* Primary outcome card */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
              
              {/* Left Column: Result Outcome (Pass/Fail) */}
              <div className="md:col-span-5 bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-6 md:p-8 rounded-3xl flex flex-col justify-between text-center relative overflow-hidden">
                
                {isLevelPassed ? (
                  // PASSED / QUALIFIED SCREEN
                  <div className="space-y-6 my-auto">
                    <div className="w-20 h-20 bg-emerald-500/10 border-2 border-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20 animate-bounce">
                      <Trophy className="w-10 h-10 text-emerald-400" />
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-2xl font-extrabold font-Cairo text-emerald-400">
                        مبارك! لقد تأهلت بنجاح
                      </h3>
                      <p className="text-xs text-slate-300 font-Cairo px-2 leading-relaxed">
                        أثبتَّ جدارة فائقة وحللت كافة المعادلات الفردية الموقوتة بامتياز. اسمك مسجل الآن ضمن نخبة لوحة الشرف للأبطال المتأهلين.
                      </p>
                    </div>

                    <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 text-center">
                      <p className="text-xs text-slate-400 font-Cairo mb-1">النتيجة النهائية للتأهل</p>
                      <div className="text-3xl font-extrabold font-mono text-emerald-400">3 / 3</div>
                      <p className="text-[10px] text-emerald-400/80 font-Cairo mt-1">تأهيل ذهبي فائق السرعة</p>
                    </div>
                  </div>
                ) : (
                  // FAILED / RETRY SCREEN
                  <div className="space-y-6 my-auto">
                    <div className="w-20 h-20 bg-rose-500/10 border-2 border-rose-400 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-rose-500/20">
                      <XCircle className="w-10 h-10 text-rose-400" />
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-2xl font-extrabold font-Cairo text-rose-400">
                        لم يحالفك الحظ
                      </h3>
                      <p className="text-xs text-slate-300 font-Cairo px-2 leading-relaxed">
                        قواعد الحساب الذهني المتقدم تتطلب الدقة المطلقة والسرعة الفائقة معاً. لا بأس، أعد المحاولة لصقل مهاراتك الرياضية أكثر!
                      </p>
                    </div>

                    <div className="bg-slate-950/60 p-4 rounded-2xl border border-rose-500/10 text-center">
                      <p className="text-xs text-slate-400 font-Cairo mb-1">المعادلات المنجزة</p>
                      <div className="text-3xl font-extrabold font-mono text-rose-400">{score} / 3</div>
                      <p className="text-[10px] text-rose-400/80 font-Cairo mt-1">المستوى يُحتسب ويعاد عند ارتكاب أي خطأ</p>
                    </div>
                  </div>
                )}

                {/* Bottom Buttons to proceed */}
                <div className="space-y-3 pt-6 border-t border-slate-800/80">
                  <button
                    onClick={startLevel1Test}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold font-Cairo py-3 px-6 rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 text-xs cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    إعادة محاولة المستوى الأول
                  </button>
                  <button
                    onClick={() => {
                      triggerSound('click');
                      setScreen('level_select');
                    }}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold font-Cairo py-2 px-6 rounded-2xl transition-all text-xs cursor-pointer"
                  >
                    العودة لقائمة المستويات
                  </button>
                </div>

              </div>

              {/* Right Column: Leaderboard List of Qualified Champions (لوحة المتأهلين الأبطال) */}
              <div className="md:col-span-7 bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-6 rounded-3xl flex flex-col justify-between">
                
                <div>
                  <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-indigo-400" />
                      <h3 className="text-lg font-extrabold font-Cairo text-slate-100">
                        قائمة الأبطال المتأهلين
                      </h3>
                    </div>
                    <span className="text-[10px] text-indigo-300 bg-indigo-500/10 px-2.5 py-1 rounded-full font-Cairo font-semibold">
                      لوحة الشرف الرسمية
                    </span>
                  </div>

                  {/* Leaderboard Table Container */}
                  <div className="overflow-y-auto max-h-[300px] pr-1 space-y-2">
                    {leaderboard.filter(player => player.qualified).length === 0 ? (
                      <div className="text-center py-10 text-slate-500 text-xs font-Cairo">
                        لا يوجد متأهلين مسجلين بعد. كن أول المتأهلين!
                      </div>
                    ) : (
                      leaderboard.filter(player => player.qualified).map((player, index) => {
                        const isCurrentUser = player.name === name.trim();
                        return (
                          <div
                            key={player.id}
                            className={`flex items-center justify-between p-3 rounded-2xl transition-all text-xs ${
                              isCurrentUser ? 'bg-indigo-500/10 border border-indigo-500/40 neon-glow' : 'bg-slate-950/60 border border-slate-800/60'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              {/* Rank position medallion */}
                              <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                                index === 0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : index === 1 ? 'bg-slate-300/20 text-slate-200' : 'bg-indigo-500/10 text-indigo-300'
                              }`}>
                                {index + 1}
                              </div>

                              <div>
                                <div className="font-bold text-slate-200 font-Cairo flex items-center gap-1.5">
                                  {player.name}
                                  {isCurrentUser && (
                                    <span className="bg-indigo-500 text-white text-[9px] px-1.5 py-0.2 rounded font-Cairo font-semibold">
                                      أنت
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-500 font-Cairo mt-0.5">
                                  {player.level} • {player.date}
                                </div>
                              </div>
                            </div>

                            <div className="text-left">
                              <span className="bg-emerald-500/10 text-emerald-400 px-2 py-1 rounded-lg text-[10px] font-Cairo font-extrabold">
                                متأهل بنجاح ({player.solvedCount}/{player.totalEquations})
                              </span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-800/50 flex items-center justify-between text-[11px] text-slate-400 font-Cairo">
                  <span>تم التسجيل محلياً في لوحة الأبطال</span>
                  <button 
                    onClick={() => {
                      if (window.confirm("هل أنت متأكد من رغبتك في إعادة تعيين كافة نتائج الأبطال؟")) {
                        localStorage.removeItem('mental_arithmetic_leaderboard');
                        setLeaderboard([]);
                        triggerSound('fail');
                      }
                    }}
                    className="text-rose-400/80 hover:text-rose-400 underline cursor-pointer"
                  >
                    إعادة ضبط القائمة
                  </button>
                </div>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* Persistent Beautiful Footer */}
      <footer id="app-footer" className="border-t border-slate-800/40 bg-slate-900/20 py-4 px-4 text-center z-10 text-xs text-slate-500 font-Cairo">
        <p>© 2026 بارق للحساب الذهني السريع. جميع الحقوق محفوظة.</p>
        <p className="text-[10px] text-slate-600 mt-1">تحديات عقلية متكاملة مصممة لتدريب المعالجة الدماغية السريعة للأرقام والعمليات الحسابية المتقدمة.</p>
      </footer>

    </div>
  );
}
